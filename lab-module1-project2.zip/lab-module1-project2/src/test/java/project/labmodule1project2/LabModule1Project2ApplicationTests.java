package project.labmodule1project2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabModule1Project2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
