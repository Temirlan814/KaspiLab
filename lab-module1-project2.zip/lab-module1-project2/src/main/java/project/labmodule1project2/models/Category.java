package project.labmodule1project2.models;

public enum Category {
    FOOD,
    ELECTRONICS,

}
